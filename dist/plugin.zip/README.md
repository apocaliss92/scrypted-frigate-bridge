# Scrypted frigate bridge

https://github.com/apocaliss92/scrypted-frigate-bridge - For requests and bugs